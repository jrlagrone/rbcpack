x=linspace(0,3e-1,100);
y=linspace(0,1.5e-1,50);
ct=1000;
for i=0:10:390
    ct=ct+1;
    A=importdata(['TE_Hz_00' sprintf('%04d',i) '.data']);
    B=reshape(A,100,50);
    surf(x,y,B');view(2);axis equal;shading interp;
    xlim([0 3e-1]);ylim([0 1.5e-1]);caxis([-0.1 0.1]);colorbar;pause(0.1);
    % print('-djpeg',['D' num2str(ct) '.jpg']);
end
