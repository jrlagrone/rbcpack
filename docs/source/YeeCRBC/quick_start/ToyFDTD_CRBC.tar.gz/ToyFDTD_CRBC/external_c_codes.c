#include <stdio.h>
#include <stdlib.h>
#include <math.h>   
#include <string.h>   
#include <3d_yee_crbc_api.h>

#ifndef XYZSHIFT
#define XYZSHIFT 0
#endif


typedef struct yeeData {

  // constants (MKS units)
  double pi;   
  double C;     // speed of light (m/s)
  double mu0;   // permeability (V*s/(A*m))
  double eps0;  // permittivity (F/m)

  // relative permeability
  double epsR; // 1.0 corresponds to a vacuum  

  // number of time steps 
  int ntsteps;    

  // grid size
  // NOTE: Field Value Locations
  //
  // Ex - at (i + 1/2, j, k)
  // Ey - at (i, j + 1/2, k)
  // Ez - at (i, j, k + 1/2)
  //  
  // Hx - at (i, j + 1/2, k + 1/2)
  // Hy - at (i + 1/2, j, k + 1/2)
  // Hz - at (i + 1/2, j + 1/2, k) 
  //
  // This means we have
  // (imax-1) * (jmax) * (kmax)   Ex field values 
  // (imax) * (jmax-1) * (kmax)   Ey field values 
  // (imax) * (jmax) * (kmax-1)   Ez field values 
  // (imax) * (jmax-1) * (kmax-1) Hx field values 
  // (imax-1) * (jmax) * (kmax-1) Hy field values 
  // (imax-1) * (jmax-1) * (kmax) Hz field values 
  int imax;   
  int jmax;   
  int kmax;  

  int nx,ny,nz;

  // grid spacing in each direction
  double dx;   
  double dy;   
  double dz;  

  // time step size, (we'll use 0.99*CFL)  
  double dt;  


  // source parameters 
  // we will use a so called impulsive source that takes the form of a 
  // differentiated gaussian centered in the domain    
  double tw;      // pulse width   
  double t0;      // delay   
  double amp;     // Amplitude 

  // permittivity, permeability 
  double epsilon;   
  double mu;   

  // a flag so we know if data has been allocated or not
  int flag;

  // update coefficients
  double CE, CH;

  int testarray[6];

  // boundary conditions
  // The type CRBC_Boundaries is an provided by the CRBC/DAB library and it is 
  // simply an enumeration of the supported boundary types. At this time, the 
  // supported boundary types are 
  //     CRBC_PEC  --- Perfect Electric Conductor
  //     CRBC_CRBC --- Complete Radiation Boundary Condition (implemented as a DAB)
  CRBC_Boundaries_t boundaries[6];

  YeeCrbcUpdater *boundary_updater;

  int LDA,LDB,LDC;

} yeeData;
       

void crbc_init_(void **p,double *dx1,double *dy1,double *dz1,int *nx1,int *ny1,int *nz1,int *lda, int *ldb, int *ldc, int *ntsteps, double *dt, double *cc);

void crbc_init(void **p,double dx1,double dy1,double dz1,int nx1,int ny1,int nz1,int lda1, int ldb1, int ldc1, int ntsteps1, double dt1, double cc1);

void setup_crbc_(yeeData *d);

void setup_crbc(yeeData *d);

double * ep_f(double *eh,int i,int j,int k, int fid,yeeData *d); // for fortran

double * ep_c(double *ex,double *ey,double *ez,int i,int j,int k, int fid,yeeData *d); // for c

void writeefield_(double *eh, void **p,char *filename1); 

void writeefield(double *ex,double *ey,double *ez,int fid,void **p,char *filename1);

void computeboundary_(double *eh, void **p);

void computeboundary(double *ex,double *ey, double *ez, void **p);

/******************************************************/
// Function implementations

void crbc_init_(void **p,double *dx1,double *dy1,double *dz1,int *nx1,int *ny1,int *nz1,int *lda, int *ldb, int *ldc, int *ntsteps, double *dt, double *cc)
{
    yeeData *d;
    d=(yeeData *) malloc(1 * sizeof(yeeData));
    *p=d;
    
    d->flag = 0;

    d->boundaries[CRBC_XLeft]  = CRBC_CRBC;
    d->boundaries[CRBC_XRight] = CRBC_CRBC;
    d->boundaries[CRBC_YLeft]  = CRBC_CRBC;
    d->boundaries[CRBC_YRight] = CRBC_CRBC;
    d->boundaries[CRBC_ZLeft]  = CRBC_CRBC;
    d->boundaries[CRBC_ZRight] = CRBC_CRBC;

    d->dx=*dx1;
    d->dy=*dy1;
    d->dz=*dz1;

    d->nx=*nx1;
    d->ny=*ny1;
    d->nz=*nz1;

    d->imax=d->nx+1;
    d->jmax=d->ny+1;
    d->kmax=d->nz+1;

    d->LDA=*lda;
    d->LDB=*ldb;
    d->LDC=*ldc;

    d->ntsteps=*ntsteps;

    d->pi = 3.14159265358979;   
//    d->C = 2.99792458e8;   

    // time step size, (we'll use 0.99*CFL)  
//    d->dt = 0.9 / (d->C*sqrt(1.0/(d->dx*d->dx) + 1.0/(d->dy*d->dy) + 1.0/(d->dz*d->dz))); 

    d->dt = *dt;
    d->C = *cc;
//    d->C = 1.0;

    d->epsR=1.0;

    // calculate free space eps and mu
    d->mu0 = 4.0 * d->pi * 1.0E-7;   
    d->eps0 = 1.0 / (d->C * d->C * d->mu0);

    // calculate material epsilon and mu
    d->epsilon = d->epsR * d->eps0;
    d->mu = d->mu0;

    // calculate update coefficients
    d->CE = d->dt / d->epsilon;
    d->CH = d->dt / d->mu0;

    // at the very end reset flag to be successful
    d->flag = 1;

    //setup_crbc(d,&(d->boundary_updater));
    setup_crbc_(d);
}

void crbc_init(void **p,double dx1,double dy1,double dz1,int nx1,int ny1,int nz1,int lda1, int ldb1, int ldc1, int ntsteps1, double dt1, double cc1)
{
    yeeData *d;
    d=(yeeData *) malloc(1 * sizeof(yeeData));
    *p=d;
    
    d->flag = 0;

    d->boundaries[CRBC_XLeft]  = CRBC_PEC;
    d->boundaries[CRBC_XRight] = CRBC_CRBC;
    d->boundaries[CRBC_YLeft]  = CRBC_PEC;
    d->boundaries[CRBC_YRight] = CRBC_PEC;
    d->boundaries[CRBC_ZLeft]  = CRBC_PEC;
    d->boundaries[CRBC_ZRight] = CRBC_PEC;

    d->dx=dx1;
    d->dy=dy1;
    d->dz=dz1;

    d->nx=nx1;
    d->ny=ny1;
    d->nz=nz1;

    d->imax=d->nx+1;
    d->jmax=d->ny+1;
    d->kmax=d->nz+1;

    d->LDA=lda1;
    d->LDB=ldb1;
    d->LDC=ldc1;

    d->ntsteps=ntsteps1;

    d->pi = 3.14159265358979;   
//    d->C = 2.99792458e8;   

    // time step size, (we'll use 0.99*CFL)  
//    d->dt = 0.9 / (d->C*sqrt(1.0/(d->dx*d->dx) + 1.0/(d->dy*d->dy) + 1.0/(d->dz*d->dz))); 

    d->dt = dt1;
    d->C = cc1;
//    d->C = 1.0;

    d->epsR=1.0;

    // calculate free space eps and mu
    d->mu0 = 4.0 * d->pi * 1.0E-7;   
    d->eps0 = 1.0 / (d->C * d->C * d->mu0);

    // calculate material epsilon and mu
    d->epsilon = d->epsR * d->eps0;
    d->mu = d->mu0;

    // calculate update coefficients
    d->CE = d->dt / d->epsilon;
    d->CH = d->dt / d->mu0;

    // at the very end reset flag to be successful
    d->flag = 1;

    //setup_crbc(d,&(d->boundary_updater));
    setup_crbc(d);
}

/*------------------------------------------------------------------------------

                      Function to initilize the CRBC updater

------------------------------------------------------------------------------*/
void setup_crbc_(yeeData *d) {

  int i, l;
  double T;
  double h[3];
  double delta;
  int low_index[3];
  int high_index[3];
  int n;
  CRBC_Fields_t comps[3];
  CRBC_Side_t side;
  
  YeeCrbcUpdater **upd=&(d->boundary_updater);

  // First we will create a new boundary updater. To do this, we need to provide
  // the total simulation time, the grid spacings, the time step size, the 
  // wave speed and the boundary conditions.
  h[0] = d->dx;
  h[1] = d->dy;
  h[2] = d->dz;
  T = d->dt * d->ntsteps; // total time is time step size * number of time steps
  *upd = CRBC_new_updater(T, h, d->dt, d->C, d->boundaries);

  // alternatively one can call 
  // int P = 7;
  // *upd = CRBC_new_updater_p(T, h, d->dt, d->C, d->boundaries, P);
  // This does exactly the same thing but changes the number of recursions from
  // the default of 5 to 7.
  //
  // or 
  // int Pmax = 15;
  // double tol = 1e-3;
  // *upd = CRBC_new_updater_tol(T, h, d->dt, d->C, d->boundaries, Pmax, tol);
  // Will generate an updater that attempts to satsify the provided tolerance
  // and with fewer than Pmax recursions.

  // Before we set up the faces, print out the properties from the boundary 
  // updater to make sure they are correct
  printf("The boundary updater was initialized with the following: \n");
  printf("  wave speed, c = %e \n", CRBC_get_c(*upd));
  printf("  total time, T = %e \n", CRBC_get_T(*upd));
  printf("  time step, dt = %e \n", CRBC_get_dt(*upd));
  printf("The boundary updater calculated the following: \n");
  printf("  %i Ex faces \n", CRBC_get_num_faces(*upd, CRBC_Ex));
  printf("  %i Ey faces \n", CRBC_get_num_faces(*upd, CRBC_Ey));
  printf("  %i Ez faces \n", CRBC_get_num_faces(*upd, CRBC_Ez));
  printf("  %i Ex edges \n", CRBC_get_num_edges(*upd, CRBC_Ex));
  printf("  %i Ey edges \n", CRBC_get_num_edges(*upd, CRBC_Ey));
  printf("  %i Ez edges \n", CRBC_get_num_edges(*upd, CRBC_Ez));
  printf("  %i Ex corners \n", CRBC_get_num_corners(*upd, CRBC_Ex));
  printf("  %i Ey corners \n", CRBC_get_num_corners(*upd, CRBC_Ey));
  printf("  %i Ez corners \n", CRBC_get_num_corners(*upd, CRBC_Ez));

  // Now set up the faces. Start by looping over all of the possible faces. We
  // follow the order given in CRBC_Side, so 
  //   l = 0 --> CRBC_XLeft
  //   l = 1 --> CRBC_XRight
  //   l = 2 --> CRBC_YLeft
  //   l = 3 --> CRBC_YRight
  //   l = 4 --> CRBC_ZLeft
  //   l = 5 --> CRBC_ZRight
  for (l=0; l<6; ++l) {

    // First we need to calculate the minimum distance between the boundary and
    // source. Since we placed the source in the center of the domain, this is 
    // simple. If it is not possible to calculate this directly, using a lower
    // bound for the seperation is the safest thing to do, but it may result
    // in more work being done that is actually needed to achieve the desired 
    // accuracy.
    switch (l / 2) {
   
      case 0: // Faces with a normal in the x-direction
        delta = (d->imax / 2) * (d->dx);
        break;
    
      case 1: // faces with a normal in the y-direction
        delta = (d->jmax / 2) * (d->dy);
        break;

      case 2: // faces with a normal in the z-direction
        delta = (d->kmax / 2) * (d->dz);
        break;
    }

    // convert the index l to a CRBC_Side_t type
    switch (l) {
      case 0:
        side = CRBC_XLeft;
        break;
      case 1:
        side = CRBC_XRight;
        break;
      case 2:
        side = CRBC_YLeft;
        break;
      case 3:
        side = CRBC_YRight;
        break;
      case 4:
        side = CRBC_ZLeft;
        break;
      case 5:
        side = CRBC_ZRight;
        break;
    }

    // Next, we'll get the field components that the updater expects. If this
    // is not a boundary that will be handled by the updater, this should 
    // return n = 0.
    CRBC_get_component_inputs(*upd, side, comps, &n);

    // Set up each component the updater has requested.
    for (i=0; i<n; ++i) {

      // The CRBC updater library attempts to communicate with the solvers "native"
      // indexing scheme, so we need to tell it the upper and lower indexing extents.
      // These extents need to include all of the requested component variables
      // on the boundary face (or just inside the boundary in the case of a normal 
      // component) as well the adjacent parallel plane of points in the interior 
      // of the domain.

      // Set the basic extents and then adjust them based on the side and field 
      // component. These should be inclusive extents;
      low_index[0] = 0;
      low_index[1] = 0;
      low_index[2] = 0;

      high_index[0] = d->imax-1; // minus 1 from 0-based indexing
      high_index[1] = d->jmax-1;
      high_index[2] = d->kmax-1; 

      switch (side) {

        case CRBC_XLeft:
          // For the left boundary in x, this means we need to include the data 
          // points of the requested component at i=0 and i=1 and all possible 
          // indices for j and k. Therefore, the lower indexing extents are 0 for
          // all indices. The upper extents vary by component. The boundary 
          // updater considers these extents to be inclusive.
                
          high_index[0]=1;      

          if (comps[i] == CRBC_Ex) {
            low_index[0] = 1;      
            high_index[0]= 2;  
          // adjust the upper extent based on the field component
          } else if (comps[i] == CRBC_Ey) {
            low_index[1]=1;
          } else if (comps[i] == CRBC_Ez) {
            low_index[2]=1;
          }

          break;

        case CRBC_XRight:
          // For the right boundary in x, this means we need to include the data
          // points of the requested component at i=imax-1 and i=imax-2 or 
          // i=imax-2 and i=imax-3 depending on the component along with all of 
          // the possible indices for j and k. The boundary updater considers 
          // these extents to be inclusive.
          low_index[0] = d->imax-2;

          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ex) {
            //low_index[0]--;
            //high_index[0]--;
          } else if (comps[i] == CRBC_Ey) {
            low_index[1]=1;
          } else if (comps[i] == CRBC_Ez) {
            low_index[2]=1;
          }

          break;

        case CRBC_YLeft:
          // For the left boundary in y, this means we need to include the data 
          // points of the requested component at j=0 and j=1 along with all of 
          // the possible indices for i and k. The boundary updater considers 
          // these extents to be inclusive.
          high_index[1] = 1;
    
          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ey) {
            low_index[1] = 1;      
            high_index[1]= 2;  
          } else if (comps[i] == CRBC_Ex) {
            low_index[0]=1;
          } else if (comps[i] == CRBC_Ez) {
            low_index[2]=1;
          }
          
          break;  

        case CRBC_YRight:
          // For the right boundary in y, this means we need to include the data
          // points of the requested component at j=jmax-1 and j=jmax-2 or 
          // j=jmax-2 and j=jmax-3 depending on the component along with all of 
          // the possible indices for i and k. The boundary updater considers 
          // extents to be inclusive.
          low_index[1] = d->jmax-2;

          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ex) {
            low_index[0]=1;
          } else if (comps[i] == CRBC_Ey) {
            //low_index[1]--;
            //high_index[1]--;
          } else if (comps[i] == CRBC_Ez) {
            low_index[2]=1;
          }
     
          break;

        case CRBC_ZLeft:
          // For the left boundary in z, this means we need to include the data 
          // points of the requested component at k=0 and k=1 along with all of 
          // the possible indices for j and k. The boundary updater considers 
          // these extents to be inclusive.
          high_index[2] = 1;
    
          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ez) {
            low_index[2] = 1;      
            high_index[2]= 2;  
          } else if (comps[i] == CRBC_Ex) {
            low_index[0]=1;
          } else if (comps[i] == CRBC_Ey) {
            low_index[1]=1;
          }

          break;

        case CRBC_ZRight:
          // For the right boundary in z, this means we need to include the data
          // points of the requested component at k=kmax-1 and k=kmax-2 or 
          // k=kmax-2 and k=kmax-3 depending on the component along with all of 
          // the possible indices for i and j. The boundary updater considers 
          // these extents to be inclusive.
          low_index[2] = d->kmax-2;
    
          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ex) {
            low_index[0]=1;
          } else if (comps[i] == CRBC_Ey) {
            low_index[1]=1;
          } else if (comps[i] == CRBC_Ez) {
            //low_index[2]--;
            //high_index[2]--;
          } 

          break;

      } // end switch side

      // now initialize the face.
      if (CRBC_init_face(*upd, side, comps[i], low_index, high_index, delta) != 0)
      {
        fprintf(stderr, "Error: init_face(...) failed \n");
        exit(-1);
      }

    }  // end for over requested components (i)
  } // end for over possible boundary faces (l)

  // now we'll print out some information about the recursions
  // NOTE  a reflection coefficient of -1 indicates that we are not performing
  // any updates on the face.
  printf("The faces were initialized with: \n");
  printf("  Left side in  x is using %i recursions "
         "with a reflection coefficient of %e \n"
         , CRBC_get_num_recursions(*upd, CRBC_XLeft), 
          CRBC_get_reflection_coef(*upd, CRBC_XLeft));
  printf("  Right side in x is using %i recursions "
         "with a reflection coefficient of %e \n"
         , CRBC_get_num_recursions(*upd, CRBC_XRight), 
         CRBC_get_reflection_coef(*upd, CRBC_XRight));
  printf("  Left side in  y is using %i recursions "
         "with a reflection coefficient of %e \n"
         , CRBC_get_num_recursions(*upd, CRBC_YLeft), 
         CRBC_get_reflection_coef(*upd, CRBC_YLeft));
  printf("  Right side in y is using %i recursions "
         "with a reflection coefficient of %e \n" 
         , CRBC_get_num_recursions(*upd, CRBC_YRight), 
         CRBC_get_reflection_coef(*upd, CRBC_YRight));
  printf("  Left side in  z is using %i recursions "
         "with a reflection coefficient of %e \n" 
         , CRBC_get_num_recursions(*upd, CRBC_ZLeft), 
         CRBC_get_reflection_coef(*upd, CRBC_ZLeft));
  printf("  Right side in z is using %i recursions "
         "with a reflection coefficient of %e \n" 
         , CRBC_get_num_recursions(*upd, CRBC_ZRight), 
         CRBC_get_reflection_coef(*upd, CRBC_ZRight));
  printf("The maximum reflection coefficient is %e \n", 
         CRBC_get_max_reflection_coef(*upd));

} // end setup_crbc_()     


void setup_crbc(yeeData *d) {

  int i, l;
  double T;
  double h[3];
  double delta;
  int low_index[3];
  int high_index[3];
  int n;
  CRBC_Fields_t comps[3];
  CRBC_Side_t side;
  
  YeeCrbcUpdater **upd=&(d->boundary_updater);

  // First we will create a new boundary updater. To do this, we need to provide
  // the total simulation time, the grid spacings, the time step size, the 
  // wave speed and the boundary conditions.
  h[0] = d->dx;
  h[1] = d->dy;
  h[2] = d->dz;
  T = d->dt * d->ntsteps; // total time is time step size * number of time steps
  *upd = CRBC_new_updater(T, h, d->dt, d->C, d->boundaries);

  // alternatively one can call 
  // int P = 7;
  // *upd = CRBC_new_updater_p(T, h, d->dt, d->C, d->boundaries, P);
  // This does exactly the same thing but changes the number of recursions from
  // the default of 5 to 7.
  //
  // or 
  // int Pmax = 15;
  // double tol = 1e-3;
  // *upd = CRBC_new_updater_tol(T, h, d->dt, d->C, d->boundaries, Pmax, tol);
  // Will generate an updater that attempts to satsify the provided tolerance
  // and with fewer than Pmax recursions.

  // Before we set up the faces, print out the properties from the boundary 
  // updater to make sure they are correct
  printf("The boundary updater was initialized with the following: \n");
  printf("  wave speed, c = %e \n", CRBC_get_c(*upd));
  printf("  total time, T = %e \n", CRBC_get_T(*upd));
  printf("  time step, dt = %e \n", CRBC_get_dt(*upd));
  printf("The boundary updater calculated the following: \n");
  printf("  %i Ex faces \n", CRBC_get_num_faces(*upd, CRBC_Ex));
  printf("  %i Ey faces \n", CRBC_get_num_faces(*upd, CRBC_Ey));
  printf("  %i Ez faces \n", CRBC_get_num_faces(*upd, CRBC_Ez));
  printf("  %i Ex edges \n", CRBC_get_num_edges(*upd, CRBC_Ex));
  printf("  %i Ey edges \n", CRBC_get_num_edges(*upd, CRBC_Ey));
  printf("  %i Ez edges \n", CRBC_get_num_edges(*upd, CRBC_Ez));
  printf("  %i Ex corners \n", CRBC_get_num_corners(*upd, CRBC_Ex));
  printf("  %i Ey corners \n", CRBC_get_num_corners(*upd, CRBC_Ey));
  printf("  %i Ez corners \n", CRBC_get_num_corners(*upd, CRBC_Ez));

  // Now set up the faces. Start by looping over all of the possible faces. We
  // follow the order given in CRBC_Side, so 
  //   l = 0 --> CRBC_XLeft
  //   l = 1 --> CRBC_XRight
  //   l = 2 --> CRBC_YLeft
  //   l = 3 --> CRBC_YRight
  //   l = 4 --> CRBC_ZLeft
  //   l = 5 --> CRBC_ZRight
  for (l=0; l<6; ++l) {

    // First we need to calculate the minimum distance between the boundary and
    // source. Since we placed the source in the center of the domain, this is 
    // simple. If it is not possible to calculate this directly, using a lower
    // bound for the seperation is the safest thing to do, but it may result
    // in more work being done that is actually needed to achieve the desired 
    // accuracy.
    switch (l / 2) {
   
      case 0: // Faces with a normal in the x-direction
        delta = (d->imax / 1.0) * (d->dx);
        break;
    
      case 1: // faces with a normal in the y-direction
        delta = (d->jmax / 2) * (d->dy);
        break;

      case 2: // faces with a normal in the z-direction
        delta = (d->kmax / 2) * (d->dz);
        break;
    }

    // convert the index l to a CRBC_Side_t type
    switch (l) {
      case 0:
        side = CRBC_XLeft;
        break;
      case 1:
        side = CRBC_XRight;
        break;
      case 2:
        side = CRBC_YLeft;
        break;
      case 3:
        side = CRBC_YRight;
        break;
      case 4:
        side = CRBC_ZLeft;
        break;
      case 5:
        side = CRBC_ZRight;
        break;
    }

    // Next, we'll get the field components that the updater expects. If this
    // is not a boundary that will be handled by the updater, this should 
    // return n = 0.
    CRBC_get_component_inputs(*upd, side, comps, &n);

    // Set up each component the updater has requested.
    for (i=0; i<n; ++i) {

      // The CRBC updater library attempts to communicate with the solvers "native"
      // indexing scheme, so we need to tell it the upper and lower indexing extents.
      // These extents need to include all of the requested component variables
      // on the boundary face (or just inside the boundary in the case of a normal 
      // component) as well the adjacent parallel plane of points in the interior 
      // of the domain.

      // Set the basic extents and then adjust them based on the side and field 
      // component. These should be inclusive extents;
      low_index[0] = 0;
      low_index[1] = 0;
      low_index[2] = 0;

      high_index[0] = d->imax-1; // minus 1 from 0-based indexing
      high_index[1] = d->jmax-1;
      high_index[2] = d->kmax-1; 

      switch (side) {

        case CRBC_XLeft:
          // For the left boundary in x, this means we need to include the data 
          // points of the requested component at i=0 and i=1 and all possible 
          // indices for j and k. Therefore, the lower indexing extents are 0 for
          // all indices. The upper extents vary by component. The boundary 
          // updater considers these extents to be inclusive.
          high_index[0] = 1;  
    
          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ey) {
            high_index[1]--;
          } else if (comps[i] == CRBC_Ez) {
            high_index[2]--;
          }

          break;

        case CRBC_XRight:
          // For the right boundary in x, this means we need to include the data
          // points of the requested component at i=imax-1 and i=imax-2 or 
          // i=imax-2 and i=imax-3 depending on the component along with all of 
          // the possible indices for j and k. The boundary updater considers 
          // these extents to be inclusive.
          low_index[0] = d->imax-2;

          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ex) {
            low_index[0]--;
            high_index[0]--;
          } else if (comps[i] == CRBC_Ey) {
            high_index[1]--;
          } else if (comps[i] == CRBC_Ez) {
            high_index[2]--;
          }

          break;

        case CRBC_YLeft:
          // For the left boundary in y, this means we need to include the data 
          // points of the requested component at j=0 and j=1 along with all of 
          // the possible indices for i and k. The boundary updater considers 
          // these extents to be inclusive.
          high_index[1] = 1;
    
          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ex) {
            high_index[0]--;
          } else if (comps[i] == CRBC_Ez) {
            high_index[2]--;
          }
          
          break;  

        case CRBC_YRight:
          // For the right boundary in y, this means we need to include the data
          // points of the requested component at j=jmax-1 and j=jmax-2 or 
          // j=jmax-2 and j=jmax-3 depending on the component along with all of 
          // the possible indices for i and k. The boundary updater considers 
          // extents to be inclusive.
          low_index[1] = d->jmax-2;

          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ex) {
            high_index[0]--;
          } else if (comps[i] == CRBC_Ey) {
            low_index[1]--;
            high_index[1]--;
          } else if (comps[i] == CRBC_Ez) {
            high_index[2]--;
          }
     
          break;

        case CRBC_ZLeft:
          // For the left boundary in z, this means we need to include the data 
          // points of the requested component at k=0 and k=1 along with all of 
          // the possible indices for j and k. The boundary updater considers 
          // these extents to be inclusive.
          high_index[2] = 1;
    
          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ex) {
            high_index[0]--;
          } else if (comps[i] == CRBC_Ey) {
            high_index[1]--;
          }

          break;

        case CRBC_ZRight:
          // For the right boundary in z, this means we need to include the data
          // points of the requested component at k=kmax-1 and k=kmax-2 or 
          // k=kmax-2 and k=kmax-3 depending on the component along with all of 
          // the possible indices for i and j. The boundary updater considers 
          // these extents to be inclusive.
          low_index[2] = d->kmax-2;
    
          // adjust the upper extent based on the field component
          if (comps[i] == CRBC_Ex) {
            high_index[0]--;
          } else if (comps[i] == CRBC_Ey) {
            high_index[1]--;
          } else if (comps[i] == CRBC_Ez) {
            low_index[2]--;
            high_index[2]--;
          } 

          break;

      } // end switch side

      // now initialize the face.
      if (CRBC_init_face(*upd, side, comps[i], low_index, high_index, delta) != 0)
      {
        fprintf(stderr, "Error: init_face(...) failed \n");
        exit(-1);
      }

    }  // end for over requested components (i)
  } // end for over possible boundary faces (l)

  // now we'll print out some information about the recursions
  // NOTE  a reflection coefficient of -1 indicates that we are not performing
  // any updates on the face.
  printf("The faces were initialized with: \n");
  printf("  Left side in  x is using %i recursions "
         "with a reflection coefficient of %e \n"
         , CRBC_get_num_recursions(*upd, CRBC_XLeft), 
          CRBC_get_reflection_coef(*upd, CRBC_XLeft));
  printf("  Right side in x is using %i recursions "
         "with a reflection coefficient of %e \n"
         , CRBC_get_num_recursions(*upd, CRBC_XRight), 
         CRBC_get_reflection_coef(*upd, CRBC_XRight));
  printf("  Left side in  y is using %i recursions "
         "with a reflection coefficient of %e \n"
         , CRBC_get_num_recursions(*upd, CRBC_YLeft), 
         CRBC_get_reflection_coef(*upd, CRBC_YLeft));
  printf("  Right side in y is using %i recursions "
         "with a reflection coefficient of %e \n" 
         , CRBC_get_num_recursions(*upd, CRBC_YRight), 
         CRBC_get_reflection_coef(*upd, CRBC_YRight));
  printf("  Left side in  z is using %i recursions "
         "with a reflection coefficient of %e \n" 
         , CRBC_get_num_recursions(*upd, CRBC_ZLeft), 
         CRBC_get_reflection_coef(*upd, CRBC_ZLeft));
  printf("  Right side in z is using %i recursions "
         "with a reflection coefficient of %e \n" 
         , CRBC_get_num_recursions(*upd, CRBC_ZRight), 
         CRBC_get_reflection_coef(*upd, CRBC_ZRight));
  printf("The maximum reflection coefficient is %e \n", 
         CRBC_get_max_reflection_coef(*upd));

} // end setup_crbc()     

double * ep_f(double * eh,int i,int j,int k, int fid,yeeData *d)
{
return eh+i+j*(d->LDA)+k*(d->LDA*d->LDB)+(fid-1)*(d->LDA*d->LDB*d->LDC);
}

double * ep_c(double * ex,double *ey,double *ez,int i,int j,int k, int fid,yeeData *d)
{
		switch (fid) {
				case 1:
						return ex+d->LDA*(i) + (d->nz+1)*(j) + k;
						break;

				case 2:
						return ey+d->LDB*(i) + (d->nz+1)*(j) + k;
						break;

				case 3:
						return ez+d->LDC*(i) + (d->nz)*(j) + k;
						break;
		}
}

void writeefield_(double *eh, void **p,char *filename1) 
{

yeeData *d;
d=(yeeData *) *p;

char efieldname[3],filename[128];
size_t ic,ij,fid,len;

strcpy(efieldname,"Ex"); fid=1;
//strcpy(efieldname,"Ey"); fid=2;
//strcpy(efieldname,"Ez"); fid=3;

len=strlen(filename1);
if (len>120) { printf("Filename too long.\n");len=120;}
ij=len;
for(ic=0;ic<len;ic++){
        if (filename1[ic]==' '){
                ij=ic;break;
        }
}
//printf("len=%u,ij=%u\n",len,ij);
strncpy(filename, filename1, ij);
strcat(filename,efieldname);
strcat(filename,".vtk");

//printf("Field=%s;",efieldname);
printf("Filename=%s\n",filename);

double dx,dy,dz,cx,cy,cz;
int nx,ny,nz;
dx=d->dx; dy=d->dy; dz=d->dz;
nx=d->imax; cx=0;
ny=d->jmax; cy=0;
nz=d->kmax; cz=0;

switch (fid){
        case 1: // Ex
                //nx--; 
                cx=-dx/2; break;
        case 2: // Ey
                //ny--; 
                cy=-dy/2; break;
        case 3: // Ez
                //nz--; 
                cz=-dz/2; break;
}

printf("dx=%e,dy=%e,dz=%e;imax=%d,jmax=%d,kmax=%d\n",dx,dy,dz,nx,ny,nz);
  int i, j, k, n, cells;

  // open the file and write the VTK header information
  FILE *f = fopen(filename, "w");

if (f==NULL){fprintf(stderr, "Difficulty opening %s\n", filename);}

  fprintf(f, "# vtk DataFile Version 3.0\n");
  fprintf(f, "vtk output\n");
  fprintf(f, "ASCII\n");
  fprintf(f, "DATASET RECTILINEAR_GRID\n");

  // set the dimensions
  fprintf(f, "DIMENSIONS %i %i %i\n", nx, ny, nz);

  // save the coordinates
  fprintf(f, "X_COORDINATES %i double \n", nx);
  for (i=0; i < nx; ++i)
    fprintf(f, "%f\n", cx + i*dx);

  fprintf(f, "Y_COORDINATES %i double \n", ny);
  for (j=0; j < ny; ++j)
    fprintf(f, "%f\n", cy + j*dy);

  fprintf(f, "Z_COORDINATES %i double \n", nz);
  for (k=0; k < nz; ++k)
    fprintf(f, "%f\n", cz + k*dz);

  // set up a cell and field
  n = nx * ny * nz;
  cells = (nx-1) * (ny-1) * (nz-1);
  fprintf(f, "CELL_DATA %i\n", cells);
  fprintf(f, "POINT_DATA %i\n", n);
  fprintf(f, "FIELD FieldData 1\n");
  fprintf(f, "%s 1 %i double\n",efieldname,n);

  // now write out the data
  for(k=0;k<nz;k++){
          for(j=0;j<ny;j++){
                  for(i=0;i<nx;i++){
                          fprintf(f,"%.12e\n",*(ep_f(eh,i,j,k,fid,d)));
                  }
          }
  }

  // close the file
  fclose(f);

}

void writeefield(double *ex, double *ey, double *ez,int fid,void **p,char *filename) 
{

yeeData *d;
d=(yeeData *) *p;

char efieldname[3];
size_t ic,ij,len;

switch (fid){
		case 1:
				strcpy(efieldname,"Ex"); break; //fid=1;
		case 2:
				strcpy(efieldname,"Ey"); break; //fid=2;
		case 3:
				strcpy(efieldname,"Ez"); break; //fid=3;
}
//printf("Field=%s;",efieldname);
printf("Filename=%s\n",filename);

double dx,dy,dz,cx,cy,cz;
int nx,ny,nz;
dx=d->dx; dy=d->dy; dz=d->dz;
nx=d->imax; cx=0;
ny=d->jmax; cy=0;
nz=d->kmax; cz=0;

switch (fid){
        case 1: // Ex
                //nx--; 
                cx=dx/2; break;
        case 2: // Ey
                //ny--; 
                cy=dy/2; break;
        case 3: // Ez
                //nz--; 
                cz=dz/2; break;
}

printf("dx=%e,dy=%e,dz=%e;imax=%d,jmax=%d,kmax=%d\n",dx,dy,dz,nx,ny,nz);
  int i, j, k, n, cells;

  // open the file and write the VTK header information
  FILE *f = fopen(filename, "w");

if (f==NULL){fprintf(stderr, "Difficulty opening %s\n", filename);}

  fprintf(f, "# vtk DataFile Version 3.0\n");
  fprintf(f, "vtk output\n");
  fprintf(f, "ASCII\n");
  fprintf(f, "DATASET RECTILINEAR_GRID\n");

  // set the dimensions
  fprintf(f, "DIMENSIONS %i %i %i\n", nx, ny, nz-1);

  // save the coordinates
  fprintf(f, "X_COORDINATES %i double \n", nx);
  for (i=0; i < nx; ++i)
    fprintf(f, "%f\n", cx + i*dx);

  fprintf(f, "Y_COORDINATES %i double \n", ny);
  for (j=0; j < ny; ++j)
    fprintf(f, "%f\n", cy + j*dy);

  fprintf(f, "Z_COORDINATES %i double \n", nz-1);
  for (k=0; k < nz-1; ++k)
    fprintf(f, "%f\n", cz + k*dz);

  // set up a cell and field
  n = (nx) * ny * (nz-1);
  cells = (nx-1) * (ny-1) * (nz-2);
  fprintf(f, "CELL_DATA %i\n", cells);
  fprintf(f, "POINT_DATA %i\n", n);
  fprintf(f, "FIELD FieldData 1\n");
  fprintf(f, "%s 1 %i double\n",efieldname,n);

		// now write out the data
		for(k=0;k<nz-1;k++){
				for(j=0;j<ny;j++){
						for(i=0;i<nx;i++){
								fprintf(f,"%.12e\n",*(ep_c(ex,ey,ez,i,j,k,fid,d)));
						}
				}
		}

  // close the file
  fclose(f);

}

/*------------------------------------------------------------------------------

                   Function to calculate the CRBC updates

------------------------------------------------------------------------------*/
void computeboundary_(double *eh, void **p) {

  yeeData *d;
  YeeCrbcUpdater *upd;
 
  d=(yeeData *) *p;
  upd=d->boundary_updater;

  int i, j, k, l, m, fid;
  //double ***field;
  int low_index[3];
  int high_index[3];
  int index[3];
  int n;
  CRBC_Fields_t components[3];
  CRBC_Side_t side;

  // first we need to copy the values that have been updated by the Yee algorithm
  // into the crbc updater. First we will loop over all of the possible sides.
  for (m=0; m<6; ++m) {

    // convert index to CRBC_Side type
    switch (m) {
      case 0:
        side = CRBC_XLeft;
        break;
      case 1:
        side = CRBC_XRight;
        break;
      case 2:
        side = CRBC_YLeft;
        break;
      case 3:
        side = CRBC_YRight;
        break;
      case 4:
        side = CRBC_ZLeft;
        break;
      case 5:
        side = CRBC_ZRight;
        break;
    }

    // Get the field components that the updater expects.
    CRBC_get_component_inputs(upd, side, components, &n);

    // loop over the components on this face
    for (l=0; l<n; l++) {

      /// get the array pointer for the correct field
      switch (components[l]) {
        case CRBC_Ex:
          //field = d->Ex;
          fid=1;
          break;
        case CRBC_Ey:
          //field = d->Ey;
          fid=2;
          break;
        case CRBC_Ez:
          //field = d->Ez;
          fid=3;
          break;
      }

      // get the indices the updater expects as input.
      // These indices are inclusive.
      CRBC_get_input_extents(upd, side, components[l], low_index, high_index);

      // copy data into the updater
      for (i=low_index[0]; i<=high_index[0]; ++i) {
        index[0] = i;
        for (j=low_index[1]; j<=high_index[1]; ++j) {
          index[1] = j;
          for (k=low_index[2]; k<=high_index[2]; ++k) {
            index[2] = k;
            //CRBC_load_face_data(upd, side, components[l], index, &(field[i][j][k]));
            CRBC_load_face_data(upd, side, components[l], index, ep_f(eh,i,j,k,fid,d));
          }
        }
      }

    } // end loop over sides
  } // end loop over sides


  // now we can compute the updates to the boundaries
  if (CRBC_compute_updates(upd) != 0) {
    fprintf(stderr, "Error: compute_updates(...) failed \n");
    exit(-1);
  }

  // Now copy the new boundary values into the arrays used by the Yee algorithm
  // loop over possible sides
  for (m=0; m<6; ++m) {

    // convert index to CRBC_Side type
    switch (m) {
      case 0:
        side = CRBC_XLeft;
        break;
      case 1:
        side = CRBC_XRight;
        break;
      case 2:
        side = CRBC_YLeft;
        break;
      case 3:
        side = CRBC_YRight;
        break;
      case 4:
        side = CRBC_ZLeft;
        break;
      case 5:
        side = CRBC_ZRight;
        break;
    }

    // Get the field components that the updater expects.
    CRBC_get_component_inputs(upd, side, components, &n);

    // loop over the components on this face
    for (l=0; l<n; l++) {

      // If there is a normal component, the Yee solver should have already
      // updated all of the values correctly. Therefore, we don't have to
      // copy the new values, so we'll just skip them.
      if (side / 2 == components[l])
        continue;

      /// get the array pointer for the correct field
      switch (components[l]) {
        case CRBC_Ex:
          //field = d->Ex;
          fid=1;      
          break;
        case CRBC_Ey:
          //field = d->Ey;
          fid=2;
          break;
        case CRBC_Ez:
          //field = d->Ez;
          fid=3;
          break;
      }

      // get the indices the updater can output.
      // These indices are inclusive.
      CRBC_get_output_extents(upd, side, components[l], low_index, high_index);

      // copy data into the updater
      for (i=low_index[0]; i<=high_index[0]; ++i) {
        index[0] = i;
        for (j=low_index[1]; j<=high_index[1]; ++j) {
          index[1] = j;
          for (k=low_index[2]; k<=high_index[2]; ++k) {
            index[2] = k;
            //field[i][j][k] = CRBC_get_new_face_vals(upd, side, components[l], index);
            *(ep_f(eh,i,j,k,fid,d)) = CRBC_get_new_face_vals(upd, side, components[l], index);
          }
        }
      }

    } // end loop over sides
  } // end loop over sides
  

} // end computeBoundary_

void computeboundary(double *ex,double *ey, double *ez, void **p) {

  yeeData *d;
  YeeCrbcUpdater *upd;
 
  d=(yeeData *) *p;
  upd=d->boundary_updater;

  int i, j, k, l, m, fid;
  double *field;
  int low_index[3];
  int high_index[3];
  int index[3];
  int n;
  CRBC_Fields_t components[3];
  CRBC_Side_t side;

  // first we need to copy the values that have been updated by the Yee algorithm
  // into the crbc updater. First we will loop over all of the possible sides.
  for (m=0; m<6; ++m) {

    // convert index to CRBC_Side type
    switch (m) {
      case 0:
        side = CRBC_XLeft;
        break;
      case 1:
        side = CRBC_XRight;
        break;
      case 2:
        side = CRBC_YLeft;
        break;
      case 3:
        side = CRBC_YRight;
        break;
      case 4:
        side = CRBC_ZLeft;
        break;
      case 5:
        side = CRBC_ZRight;
        break;
    }

    // Get the field components that the updater expects.
    CRBC_get_component_inputs(upd, side, components, &n);

    // loop over the components on this face
    for (l=0; l<n; l++) {

      /// get the array pointer for the correct field
      switch (components[l]) {
        case CRBC_Ex:
          field = ex;
          fid=1;
          break;
        case CRBC_Ey:
          field = ey;
          fid=2;
          break;
        case CRBC_Ez:
          field = ez;
          fid=3;
          break;
      }

      // get the indices the updater expects as input.
      // These indices are inclusive.
      CRBC_get_input_extents(upd, side, components[l], low_index, high_index);

      // copy data into the updater
      for (i=low_index[0]; i<=high_index[0]; ++i) {
        index[0] = i;
        for (j=low_index[1]; j<=high_index[1]; ++j) {
          index[1] = j;
          for (k=low_index[2]; k<=high_index[2]; ++k) {
            index[2] = k;
            //CRBC_load_face_data(upd, side, components[l], index, &(field[i][j][k]));
            CRBC_load_face_data(upd, side, components[l], index, ep_c(ex,ey,ez,i,j,k,fid,d));
          }
        }
      }

    } // end loop over sides
  } // end loop over sides


  // now we can compute the updates to the boundaries
  if (CRBC_compute_updates(upd) != 0) {
    fprintf(stderr, "Error: compute_updates(...) failed \n");
    exit(-1);
  }

  // Now copy the new boundary values into the arrays used by the Yee algorithm
  // loop over possible sides
  for (m=0; m<6; ++m) {

    // convert index to CRBC_Side type
    switch (m) {
      case 0:
        side = CRBC_XLeft;
        break;
      case 1:
        side = CRBC_XRight;
        break;
      case 2:
        side = CRBC_YLeft;
        break;
      case 3:
        side = CRBC_YRight;
        break;
      case 4:
        side = CRBC_ZLeft;
        break;
      case 5:
        side = CRBC_ZRight;
        break;
    }

    // Get the field components that the updater expects.
    CRBC_get_component_inputs(upd, side, components, &n);

    // loop over the components on this face
    for (l=0; l<n; l++) {

      // If there is a normal component, the Yee solver should have already
      // updated all of the values correctly. Therefore, we don't have to
      // copy the new values, so we'll just skip them.
      if (side / 2 == components[l])
        continue;

      /// get the array pointer for the correct field
      switch (components[l]) {
        case CRBC_Ex:
          field = ex;
          fid=1;      
          break;
        case CRBC_Ey:
          field = ey;
          fid=2;
          break;
        case CRBC_Ez:
          field = ez;
          fid=3;
          break;
      }

      // get the indices the updater can output.
      // These indices are inclusive.
      CRBC_get_output_extents(upd, side, components[l], low_index, high_index);

      // copy data into the updater
      for (i=low_index[0]; i<=high_index[0]; ++i) {
        index[0] = i;
        for (j=low_index[1]; j<=high_index[1]; ++j) {
          index[1] = j;
          for (k=low_index[2]; k<=high_index[2]; ++k) {
            index[2] = k;
            //field[i][j][k] = CRBC_get_new_face_vals(upd, side, components[l], index);
            *(ep_c(ex,ey,ez,i,j,k,fid,d)) = CRBC_get_new_face_vals(upd, side, components[l], index);
          }
        }
      }

    } // end loop over sides
  } // end loop over sides
  

} // end computeBoundary

/***********************************************/
/**************temp testing functions***********/
/***********************************************/

void crbc_test_(void **p)
{
    yeeData *d;    
    YeeCrbcUpdater *upd;        
    
    d=(yeeData *) *p;
    upd=d->boundary_updater;

  printf("~~~~~~~~~~~~~~~~~~~~TEST from CRBC~~~~~~~~~~~~~~~~~~~~~~~~~\n");
  printf("lda,ldb,ldc,nt,dt=%d,%d,%d,%d,%e\n",d->LDA,d->LDB,d->LDC,d->ntsteps,d->dt);
  printf("  Left side in  x is using %i recursions "
         "with a reflection coefficient of %e \n"
         , CRBC_get_num_recursions(upd, CRBC_XLeft), 
          CRBC_get_reflection_coef(upd, CRBC_XLeft));
  printf("  Right side in x is using %i recursions "
         "with a reflection coefficient of %e \n"
         , CRBC_get_num_recursions(upd, CRBC_XRight), 
         CRBC_get_reflection_coef(upd, CRBC_XRight));
  printf("  Left side in  y is using %i recursions "
         "with a reflection coefficient of %e \n"
         , CRBC_get_num_recursions(upd, CRBC_YLeft), 
         CRBC_get_reflection_coef(upd, CRBC_YLeft));
  printf("  Right side in y is using %i recursions "
         "with a reflection coefficient of %e \n" 
         , CRBC_get_num_recursions(upd, CRBC_YRight), 
         CRBC_get_reflection_coef(upd, CRBC_YRight));
  printf("  Left side in  z is using %i recursions "
         "with a reflection coefficient of %e \n" 
         , CRBC_get_num_recursions(upd, CRBC_ZLeft), 
         CRBC_get_reflection_coef(upd, CRBC_ZLeft));
  printf("  Right side in z is using %i recursions "
         "with a reflection coefficient of %e \n" 
         , CRBC_get_num_recursions(upd, CRBC_ZRight), 
         CRBC_get_reflection_coef(upd, CRBC_ZRight));
  printf("The maximum reflection coefficient is %e \n", 
         CRBC_get_max_reflection_coef(upd));
}



void init_data_test_(void **d)
{
    yeeData *pr,*pr2;
    pr=(yeeData *) malloc(1 * sizeof(yeeData));
    pr->C=3e8;
    printf("\n &d =  %p",(void *) &d);
    printf("\n  d =  %p",(void *)  d);
    printf("\n *d =  %p",(void *) *d);
    *d=pr;
    printf("\nAddress of pr = %p",(void *) &pr);
    printf("\nAddress of d =  %p",(void *) &d);
    printf("\nValue of pr = %p", (void *) pr);
    printf("\nValue of d =  %p\n", (void *) d);
    printf("\nValue of *d =  %p\n", (void *) *d);

    int i;
    for(i=0;i<6;i++){
        pr->testarray[i]=i+1;
    }

    pr2=(yeeData *)*d;
    printf("CC=%e\n",pr2->C);
    
}

void receive_data_test_(void **d)
{
    yeeData *pr;
    pr=(yeeData *) (*d);
    int i=5;
    printf("C_from_external d=%p\n",(void *) *d);
    printf("C_from_external=%e\n",pr->C);
    printf("C_from_external: testarray[%d]=%d\n",i,pr->testarray[i]);

}


void writefieldhead_(char *fieldname1,double *dx1,double *dy1,double *dz1,int *nx1,int *ny1,int *nz1, char *filename1) 
{
char fieldname[3],filename[7];
fieldname[0]=fieldname1[0];
fieldname[1]=fieldname1[1];
fieldname[2]='\0';

filename[0]=filename1[0];
filename[1]=filename1[1];
filename[2]=filename1[2];
filename[3]=filename1[3];
filename[4]=filename1[4];
filename[5]=filename1[5];
filename[6]=filename1[6];
filename[7]=filename1[7];
filename[8]=filename1[8];
filename[9]=filename1[9];
filename[10]='\0';

printf("Field=%s;",fieldname);
printf("Filename=%s\n",filename);

double dx,dy,dz;
int nx,ny,nz;
dx=*dx1;dy=*dy1;dz=*dz1;
nx=*nx1;ny=*ny1;nz=*nz1;

printf("dx=%e,dy=%e,dz=%e;nx=%d,ny=%d,nz=%d\n",dx,dy,dz,nx,ny,nz);
  int i, j, k, n, cells;

  // open the file and write the VTK header information
  FILE *f = fopen(filename, "w");

if (f==NULL){fprintf(stderr, "Difficulty opening %s\n", filename);}

  fprintf(f, "# vtk DataFile Version 3.0\n");
  fprintf(f, "vtk output\n");
  fprintf(f, "ASCII\n");
  fprintf(f, "DATASET RECTILINEAR_GRID\n");

  // set the dimensions
  fprintf(f, "DIMENSIONS %i %i %i\n", nx, ny, nz);

  // save the coordinates
  fprintf(f, "X_COORDINATES %i double \n", nx);
  for (i=0; i < nx; ++i)
    fprintf(f, "%f\n", 0.0*dx/2.0 + i*dx);

  fprintf(f, "Y_COORDINATES %i double \n", ny);
  for (j=0; j < ny; ++j)
    fprintf(f, "%f\n", 1.0*dy/2.0 + j*dy);

  fprintf(f, "Z_COORDINATES %i double \n", nz);
  for (k=0; k < nz; ++k)
    fprintf(f, "%f\n", 1.0*dz/2.0 + k*dz);

  // set up a cell and field
  n = (nx) * ny * nz;
  cells = (nx-1) * (ny-1) * (nz-1);
  fprintf(f, "CELL_DATA %i\n", cells);
  fprintf(f, "POINT_DATA %i\n", n);
  fprintf(f, "FIELD FieldData 1\n");
  fprintf(f, "%s 1 %i double\n",fieldname,n);

//  // now write out the data
//  for (k=0; k < nz; ++k) 
//    for (j=0; j < ny; ++j)
//      for (i=0; i < nx; ++i)
//        fprintf(f, "%f\n", d->Ex[i][j][k]);
  	

  // close the file
  fclose(f);
}


void writefield(double *eh,yeeData *d,int fid,char *filename)
{
    int nx,ny,nz,i,j,k;
    nx=d->imax;
    ny=d->jmax;
    nz=d->kmax;
//    switch (fid){
//        case 1: // Ex
//                nx--;  break;
//        case 2: // Ey
//                ny--;  break;
//        case 3: // Ez
//                nz--;  break;
//    }

    FILE *f = fopen(filename, "a");
    if (f==NULL){fprintf(stderr, "Difficulty opening %s\n", filename);}

    for(k=0;k<nz;k++){
            for(j=1;j<ny;j++){
                    for(i=0;i<nx;i++){
                            fprintf(f,"%lf\n",*(ep_f(eh,i,j,k,fid,d)));
                    }
            }
    }
    fclose(f);
}    
    
void printstringtest_(char *stringname) 
{
char cstr[64];
size_t i,j,len;
len=strlen(stringname);
j=len;
for(i=0;i<len;++i){
        if (stringname[i]==' '){
                j=i;break;
        }
}
sprintf(cstr,"%s","what is this");
printf("%s\n",stringname);
        printf("len=%u\n",(unsigned)strlen(stringname));
        printf("j=%u\n",(unsigned) j);
}

